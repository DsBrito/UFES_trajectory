#ifndef LISTA_H
#define LISTA_H


#include <stdlib.h>
#include <stdio.h>

typedef struct lista Lista;
typedef struct celula Celula;

//Funções de criação
Lista* CriaLista();
Celula * CriaCelula(int id, void * item);

//Funções de inserir
void InsereRoteador(Lista* lista, char* roteador,char* Operadora);
void InsereLista(Lista* lista, Celula * cel);
void InsereTerminal(Lista* lista, char* terminal,char* Operadora);
void InsereListaRoteador(Lista* RoteadorLista, Lista* ListaDoRoteador,char* rot1);

//Funções auxiliares
Celula * RetornaListaUlti(Lista * l);
Celula * RetornaCelulaProx(Celula * cel);
Celula * RetornaListaPrim(Lista * l);
void* RetornaCelulaItem(Celula * celula);
int VerificaVazia(Lista * lista);
void ListaAtribuiNULL(Lista* lista);
void ListaAtribuiProx(Lista* lista, Celula* celula);
void ListaAtribuiUlt(Lista* lista, Celula* celula);
void CelulaAtribuiProx(Celula* ant,Celula* p);

//Funções de remoção
Lista* RemoveRoteador(Lista* RoteadorLista, Lista* terminais, char* rot1,FILE* ArquivoLog);
void RemoveRoteadorDaListadeTerminais(Lista* TerminalLista,char* rot);
Lista* RemoveTerminal(Lista* TerminalLista, char* ter, FILE* ArquivoLog);

//Desconecta roteadores
void DesconectaRoteadores(char* rot1, char* rot2, Lista* RoteadorLista, FILE* ArquivoLog);

//Impressão do NETMAP
void ImprimeNetMap(Lista* RoteadorLista, Lista* TerminalLista,FILE* NetMapArquivo);



//arrumar
Lista* RemoveTerminal(Lista* TerminalLista, char* ter, FILE* ArquivoLog);
void FrequenciaOperadora(char* op,Lista* RoteadorLista,FILE* SaidaArquivo);
void FrequenciaTerminal(char* local, Lista* TerminalLista,FILE* SaidaArquivo);

void liberaRoteadoresLista(Lista* RoteadorLista);

void liberaTerminaisLista(Lista* TerminalLista);


//Libera a lista de terminais, depois a lista de roteadores
void encerraNetMap(Lista* RoteadorLista, Lista* TerminalLista);
#endif /* LISTA_H */

        

