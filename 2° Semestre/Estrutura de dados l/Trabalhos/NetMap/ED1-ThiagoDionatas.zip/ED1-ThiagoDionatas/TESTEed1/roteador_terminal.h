

#ifndef ROTEADOR_TERMINAL_H
#define ROTEADOR_TERMINAL_H

#include <stdio.h>
#include "lista.h"

typedef struct roteador Roteador;
typedef struct terminal Terminal;

//Cadastramento

Roteador* cadastraRoteador(char* nome, char* op);
Terminal* cadastraTerminal(char* nome, char* op);

//Retorno Terminais
char* RetornaNomeTerminal(Terminal* ter);
char* retornaOperadoraTerminal(Terminal* ter);
Roteador* retornaRoteadorTerminal(Terminal* ter);

//Retorno Roteadores
char* retornaOperadoraRoteador(Roteador* rot);
char* retornaNomeRoteador(Roteador* rot);
Lista* RetornaListaRoteador(Roteador* rot);

//Compara Terminal/Terminal Roteador/Roteador
int ComparaTerminal (Terminal* ter, char* nome);
int ComparaRoteador (Roteador* rot, char* nome);

//Retorna Roteador/Terminal de uma lista
Roteador * RetornaRoteador(Lista* RoteadorLista, char* rot);
Terminal * RetornaTerminal(Lista* TerminalLista, char* ter);

//Desconexão de Roteador/Roteador Terminal/Roteador

void atribuiNULLTerminal(Terminal* ter);
Roteador* RetiraConexaoRoteador(Lista* RoteadorLista, char* rot);
Terminal* RemoveTerminalDaLista(Lista* TerminalLista, char* ter);

//Conecta Roteador/Roteador Roteador/Terminal

void ConectaRoteadores(Lista* RoteadorLista, char* rot1, char* rot2, FILE* ArquivoLog);
void ConectaTerminalRoteador(Lista* RoteadorLista, Lista* TerminalLista, char* ter, char* rot, FILE* ArquivoLog);

//Libera structs Terminal e Roteador
void LiberaTerminal(Terminal* ter);
void LiberaRoteador(Roteador* rot);




//arrumar
 void DesconectaTerminal(char* ter, Lista* ListaTerminais, FILE* ArquivoLog);
 int VerificaConexao(Roteador* rot1, Roteador* rot2, Lista* temp);

#endif /* ROTEADOR_TERMINAL_H */

