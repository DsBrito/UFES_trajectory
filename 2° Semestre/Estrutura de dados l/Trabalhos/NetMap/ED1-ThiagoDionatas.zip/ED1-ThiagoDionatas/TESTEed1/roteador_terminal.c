/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "roteador_terminal.h"
#include "lista.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

//////////////////////////////////////////////////////////////
//Declaração das structs
struct roteador{
    char* nome;
    char* op;
    Lista* conexoes;
};

struct terminal{
    char* nome;
    char* op;
    Roteador* rot; 
};
//////////////////////////////////////////////////////////////

//Funções de cadastramento

Roteador* cadastraRoteador(char* nome, char* op){
    Roteador* rot = (Roteador*)malloc(sizeof(Roteador));
    rot->conexoes = CriaLista();
    rot->nome = strdup(nome);
    rot->op = strdup(op);
    return rot;
}

Terminal* cadastraTerminal(char* nome, char* op){
    Terminal* ter = (Terminal*)malloc(sizeof(Terminal));
    ter->nome = strdup(nome);
    ter->op = strdup(op);
    ter->rot=NULL;
    
    return ter;
}

////////////////////////////////////////

//Funções de retorno de terminal

char* RetornaNomeTerminal(Terminal* ter){
    return ter->nome;   
}

char* retornaOperadoraTerminal(Terminal* ter){
    return ter->op;
}


Roteador* retornaRoteadorTerminal(Terminal* ter){
    return ter->rot;
}

////////////////////////////////////////

//Funções de retorno de roteadores


char* retornaNomeRoteador(Roteador* rot){
    return rot->nome;
}

char* retornaOperadoraRoteador(Roteador* rot){
    return rot->op;
}

Lista* RetornaListaRoteador(Roteador* rot){
    return rot->conexoes;
}


////////////////////////////////////////


//Compara Terminais/Roteadores


int ComparaRoteador (Roteador* rot, char* nome) {
    return strcmp(retornaNomeRoteador(rot), nome);
}

int ComparaTerminal (Terminal* ter, char* nome){
    return strcmp(ter->nome, nome);
}

// Desconecta Terminal

void DesconectaTerminal(char* ter, Lista* ListaTerminais, FILE* ArquivoLog){
    Terminal* ter1 = RetornaTerminal(ListaTerminais, ter);
    if(ter1 == NULL){
        fprintf(ArquivoLog, "ERRO: terminal  %s não existe \n", ter);
        free(ter);
        return;
    }
    atribuiNULLTerminal(ter1);
}

//Atribui NULL a conexão do terminal(desconecta o terminal do roteador)

void atribuiNULLTerminal(Terminal* ter){
    ter->rot = NULL;
}

/////////////////////////////////////////

//Funções que retornam o Roteador/Terminal a partir de um char*

//Percorre a lista de roteadores e retorna o terminal com o nome identico a rot
Roteador * RetornaRoteador(Lista* RoteadorLista, char* rot) {
    Celula * celula = RetornaListaPrim(RoteadorLista);
    Roteador * roteador_aux;

    if (VerificaVazia(RoteadorLista))
        printf("\n\nA LISTA ROTEADOR ESTA VAZIA!!\n\n");

    else {
        while (celula != NULL) {
            roteador_aux = RetornaCelulaItem(celula);
            if(roteador_aux==NULL)
                break;
            
            if (!ComparaRoteador(roteador_aux,rot))
                return roteador_aux;

            celula = RetornaCelulaProx(celula);
        }
        return roteador_aux;
    }

    return NULL;
}

//Percorre a lista de terminais e retorna o terminal com o nome identico a ter
Terminal * RetornaTerminal(Lista* TerminalLista, char* ter) {
    Celula * celula = RetornaListaPrim(TerminalLista);
    Terminal * terminal_aux;

    if (VerificaVazia(TerminalLista))
        printf("\n\nA LISTA TERMINAL ESTA VAZIA!!\n\n");

    else {
        while (celula != NULL) {
            terminal_aux = RetornaCelulaItem(celula);

            if (!ComparaTerminal(terminal_aux, ter))
                return terminal_aux;

            celula = RetornaCelulaProx(celula);
        }
        return terminal_aux;
    }

    return NULL;
}

/////////////////////////////////////////

//Conecta Roteadores ou Terminal/Roteador

//Conecta Roteadores inserindo o roteador na lista de conexões do outro roteador
void ConectaRoteadores(Lista* RoteadorLista, char* rot1, char* rot2, FILE* ArquivoLog){
    Roteador* roteador=RetornaRoteador(RoteadorLista,rot1);
    if(roteador == NULL){
        fprintf(ArquivoLog, "ERRO: terminal  %s não existe \n", rot1);
        free(rot1);
        free(rot2);
        return;
    }
    Roteador* roteador2=RetornaRoteador(RoteadorLista,rot2);
    if(roteador2 == NULL){
        fprintf(ArquivoLog, "ERRO: terminal  %s não existe \n", rot2);
        free(rot1);
        free(rot2);
        return;
    }
        
    if(roteador != roteador2){
        InsereListaRoteador(RoteadorLista,RetornaListaRoteador(roteador), rot2);
        InsereListaRoteador(RoteadorLista,RetornaListaRoteador(roteador2), rot1);
    }
    else{
        InsereListaRoteador(RoteadorLista,RetornaListaRoteador(roteador), rot2);
    }
    
}

//Conecta Terminal/Roteador atribuindo um ponteiro do roteador para o terminal
void ConectaTerminalRoteador(Lista* RoteadorLista, Lista* TerminalLista, char* ter, char* rot, FILE* ArquivoLog){
    Terminal* ter1 = RetornaTerminal(TerminalLista, ter);
    if(ter1 == NULL){
        fprintf(ArquivoLog, "ERRO: terminal  %s não existe \n", ter);
        free(ter);
        free(rot);
        return;
    }
    Roteador* rot1 = RetornaRoteador(RoteadorLista, rot);
    if(rot1 == NULL){
        fprintf(ArquivoLog, "ERRO: roteador  %s não existe \n", rot);
        free(ter);
        free(rot);
        return;
    }

    ter1->rot = rot1;
    
}

///////////////////////////////////////////





//Retira o Roteador removido da lista de conexões do roteador
Roteador* RetiraConexaoRoteador(Lista* RoteadorLista, char* rot){
    Celula* p= RetornaListaPrim(RoteadorLista);
    Roteador* a;
    Celula* ant = NULL;         
    while(p!=NULL && strcmp(retornaNomeRoteador(RetornaCelulaItem(p)),rot)){
       
        ant = p;
        p=RetornaCelulaProx(p);
    
    }

    //lista vazia
    if (p == NULL){
        return NULL;
    }

    a= RetornaCelulaItem(p);


    if(RetornaCelulaItem(p)==RetornaCelulaItem(RetornaListaPrim(RoteadorLista)) && RetornaCelulaItem(p)==RetornaCelulaItem(RetornaListaUlti(RoteadorLista))){
        ListaAtribuiNULL(RoteadorLista);
    }
    else if(RetornaCelulaItem(p) == RetornaCelulaItem(RetornaListaPrim(RoteadorLista))){
        ListaAtribuiProx(RoteadorLista, p);
    }
    else if(RetornaCelulaItem(p) ==  RetornaCelulaItem(RetornaListaUlti(RoteadorLista))){
        ListaAtribuiUlt(RoteadorLista, ant);
       
    }
    else{
        CelulaAtribuiProx(ant,p);
    }
    return a;
}
/////////////////////////////////////////////////////


//Retira o Terminal da lista de Terminais

Terminal* RemoveTerminalDaLista(Lista* TerminalLista, char* ter){
    Celula* p = RetornaListaPrim(TerminalLista);
    Terminal* ter1;
    Celula* ant = NULL;

    while(p != NULL && !ComparaTerminal(RetornaCelulaItem(p), ter)){
        ant = p;
        p=RetornaCelulaProx(p);
    }

    ter1 = RetornaCelulaItem(p);

    if(p == NULL)return NULL;

    if(RetornaCelulaItem(p) == RetornaCelulaItem(RetornaListaPrim(TerminalLista)) && RetornaCelulaItem(p) == RetornaCelulaItem(RetornaListaUlti(TerminalLista))){
        ListaAtribuiNULL(TerminalLista);
    }
    else if (RetornaCelulaItem(p) == RetornaCelulaItem(RetornaListaPrim(TerminalLista))){
        ListaAtribuiProx(TerminalLista,p);
    }
    else if (RetornaCelulaItem(p) ==  RetornaCelulaItem(RetornaListaUlti(TerminalLista))){
        ListaAtribuiUlt(TerminalLista,p);
    }
    else{
        CelulaAtribuiProx(p,ant);
    }
    return ter1;
}
/////////////////////////////////////////////////////

//Libera terminal
void LiberaTerminal(Terminal* ter){
    free(RetornaNomeTerminal(ter));
    atribuiNULLTerminal(ter);
    free(retornaOperadoraTerminal(ter));
    free(ter);
}

//Libera roteador
void LiberaRoteador(Roteador* rot){
    free(retornaNomeRoteador(rot));
    free(retornaOperadoraRoteador(rot));
    free(rot);
}




///////////////////////////////////////////////////////////////////////////////////

//Verifica conexão entre dois roteadores recursivamente
int VerificaConexao(Roteador* rot1, Roteador* rot2, Lista* temp){
    Celula* p;
    //Como será uma lista temporária, é inserido como um roteador novo somente para sinalizar que já passou por ele
    
    
    InsereRoteador(temp, retornaNomeRoteador(rot1), retornaOperadoraRoteador(rot1)); 
    if(!ComparaRoteador(rot2,retornaNomeRoteador(rot1))) {
      
        return 1;
    }
    else{
        
        for(p = RetornaListaPrim(RetornaListaRoteador(rot1)); p != NULL; p = RetornaCelulaProx(p)){
            
            if(RetornaRoteador(temp, retornaNomeRoteador(RetornaCelulaItem(p)))!=NULL) { 
                
                continue;}
            
           
                if(VerificaConexao(RetornaCelulaItem(p), rot2, temp)) return 1;
        }
    }
    return 0;
}
