#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lista.h"
#include "roteador_terminal.h"


#define ROTEADOR 1
#define TERMINAL 2

//Definindo as structs lista e celula
struct lista {
    Celula* prim;
    Celula* ult;
};

struct celula {
    Celula* prox;
    void* item;
    int Id;
};

//////////////////////////////////////////////

//Cria Lista

Lista* CriaLista() {
    Lista* lista = (Lista*) malloc(sizeof (Lista));
    lista->prim = lista->ult = NULL;
    return lista;
}

//Cria Celula

Celula * CriaCelula(int id, void * item) {
    Celula * celula = (Celula*) malloc(sizeof (Celula));
    celula->prox = NULL;
    celula->Id = id;
    celula->item = item;
    return celula;
}

//////////////////////////////////////////

//Insere um Roteador novo a uma lista

void InsereRoteador(Lista* lista, char* roteador,char* Operadora){
    Roteador* rot = cadastraRoteador(roteador,Operadora);
    Celula* nova = CriaCelula(ROTEADOR,rot);
    InsereLista(lista,nova);
}

//Insere um roteador já existente a uma lista, auxiliar para inserir a lista de conexões o roteador desejado
void InsereListaRoteador(Lista* RoteadorLista, Lista* ListaDoRoteador,char* rot1){
    Roteador* roteador=RetornaRoteador(RoteadorLista,rot1) ;
    Celula* cel = CriaCelula(ROTEADOR, roteador);
    InsereLista(ListaDoRoteador, cel);
}

//Insere uma celula a uma lista
void InsereLista(Lista* lista, Celula * cel) {
    if (lista == NULL) {
        Lista* l = CriaLista();
        InsereLista(l, cel);
    } else {
        if (lista->prim == NULL) {
            lista->ult = cel;
            lista->prim = cel;
            lista->ult->prox = NULL;
        } else {
            lista->ult->prox = cel;
            lista->ult = cel;
            lista->ult->prox = NULL;
        }
    }
}

//Insere um terminal novo a uma lista
void InsereTerminal(Lista* lista, char* terminal,char* Operadora){
    Terminal* ter=cadastraTerminal(terminal,Operadora);
    Celula * nova = CriaCelula(TERMINAL,ter);
    InsereLista(lista,nova);
}

/////////////////////////////////////////////////

//Retorna valores de uma lista e de celulas e verifica se esta vazia
Celula * RetornaListaPrim(Lista * l) {
    if (l == NULL || l->prim == NULL)
        return NULL;
    else
        return l->prim;
}

Celula * RetornaListaUlti(Lista * l) {
    if (l == NULL || l->prim == NULL)
        return NULL;
    else
        return l->ult;
}

int VerificaVazia(Lista * lista) {
    if (lista->prim == NULL || lista == NULL) {
        return 1;
    } else
        return 0;
}

void* RetornaCelulaItem(Celula * celula) {
    if (celula->Id == ROTEADOR)
        return (Roteador*) celula->item;
    
    if (celula->Id == TERMINAL)
        return (Terminal*) celula->item;
}


Celula * RetornaCelulaProx(Celula * cel) {
    return cel->prox;
}

//////////////////////////////////////////////////
//Funções auxiliares para funções de retira
void ListaAtribuiNULL(Lista* lista){
    lista->prim= lista->ult =NULL;
}

void ListaAtribuiProx(Lista* lista, Celula* celula){
    lista->prim = celula->prox;
    
}

void ListaAtribuiUlt(Lista* lista, Celula* celula){
   
     lista->ult = celula;
     lista->ult->prox = NULL;
}

void CelulaAtribuiProx(Celula* ant,Celula* p){
        ant->prox= p->prox;

};

///////////////////////////////////////////////



//Remove o roteador de todas as listas de conexoes entre os outros roteadores, depois retira da lista principal liberando o roteador na memoria
Lista* RemoveRoteador(Lista* RoteadorLista, Lista* TerminalLista, char* rot1,FILE* ArquivoLog){  
    Celula* p= RetornaListaPrim(RoteadorLista);
    Roteador* roteador;
    Celula* ant = NULL;
   
    if(RetornaRoteador(RoteadorLista,rot1)==NULL){
        fprintf(ArquivoLog, "ERRO: roteador  %s não existe \n", rot1);
        free(rot1);
        return RoteadorLista;
    }
    RemoveRoteadorDaListadeTerminais(TerminalLista,rot1);
    for(p = RetornaListaPrim(RoteadorLista); p != NULL; p = RetornaCelulaProx(p)){
        RetiraConexaoRoteador(RetornaListaRoteador(RetornaCelulaItem(p)), rot1);
    }
    roteador=RetiraConexaoRoteador(RoteadorLista, rot1);
    free(roteador);
    return RoteadorLista;
      
}

void DesconectaRoteadores(char* rot1, char* rot2, Lista* RoteadorLista, FILE* ArquivoLog){
    Roteador* roteador=RetornaRoteador(RoteadorLista,rot1);
    if(roteador == NULL){
        fprintf(ArquivoLog, "ERRO: terminal  %s não existe \n", rot1);
        free(rot1);
        free(rot2);
        return;
    }
    Roteador* roteador2=RetornaRoteador(RoteadorLista,rot2);
    if(roteador2 == NULL){
        fprintf(ArquivoLog, "ERRO: terminal  %s não existe \n", rot2);
        free(rot1);
        free(rot2);
        return;
    }
        
    if(roteador != roteador2){
        RetiraConexaoRoteador(RetornaListaRoteador(roteador), rot2);
        RetiraConexaoRoteador(RetornaListaRoteador(roteador2), rot1);
    }
}


//Remove roteador da lista de terminais
void RemoveRoteadorDaListadeTerminais(Lista* TerminalLista,char* rot) {
    if (TerminalLista != NULL) {
        Celula * celula = TerminalLista->prim;
        Celula * celula2;
            for(celula2 = celula ; celula2 != NULL; celula2 = celula2->prox){
                if(retornaRoteadorTerminal(RetornaCelulaItem(celula2))==NULL)
                       continue;      
                if(!ComparaRoteador(retornaRoteadorTerminal(RetornaCelulaItem(celula2)), rot)){
                    atribuiNULLTerminal((RetornaCelulaItem(celula2)));
                }
        }
    }
}



//Verifica se terminal existe, se existir, remove da lista principal liberando a memória
Lista* RemoveTerminal(Lista* TerminalLista, char* ter, FILE* ArquivoLog){
    if(RetornaTerminal(TerminalLista, ter)==NULL){
        fprintf(ArquivoLog, "ERRO: terminal %s não existe \n", ter);
        free(ter);
        return TerminalLista;
    }
    Terminal* ter1 = RemoveTerminalDaLista(TerminalLista, ter);
    LiberaTerminal(ter1);
    return TerminalLista;
}






 
 void ImprimeNetMap(Lista* RoteadorLista, Lista* TerminalLista, FILE* NetMapArquivo) {
    Celula* aux1;
    Celula* aux2;
    fprintf(NetMapArquivo, "strict graph { ");
    for(aux1 = RetornaListaPrim(TerminalLista); aux1 != NULL; aux1 = RetornaCelulaProx(aux1)){
        if(retornaRoteadorTerminal(RetornaCelulaItem(aux1)) == NULL) continue;
        fprintf(NetMapArquivo, "%s -- %s;", RetornaNomeTerminal(RetornaCelulaItem(aux1)), retornaNomeRoteador(retornaRoteadorTerminal(RetornaCelulaItem(aux1))));
    }
    for(aux1 = RetornaListaPrim(RoteadorLista); aux1 != NULL; aux1 = RetornaCelulaProx(aux1)){
        if(RetornaListaPrim(RetornaListaRoteador(RetornaCelulaItem(aux1))) != NULL){
            
            for(aux2 = RetornaListaPrim(RetornaListaRoteador(RetornaCelulaItem(aux1))); aux2 != NULL; aux2 = RetornaCelulaProx(aux2)){
                fprintf(NetMapArquivo, "%s -- %s;", retornaNomeRoteador(RetornaCelulaItem(aux1)), retornaNomeRoteador(RetornaCelulaItem(aux2)));
            }
        }
    }
    fprintf(NetMapArquivo, "}\n\n");

   fclose(NetMapArquivo);
    }

//FrequenciaOperadora(operadora): Imprime o número de roteadores cadastrados de uma determinada operadora.
void FrequenciaOperadora(char* op,Lista* RoteadorLista,FILE* SaidaArquivo ){
    int OperCont=0;
    Celula* aux;

            
   for(aux = RetornaListaPrim(RoteadorLista); aux!= NULL; aux = RetornaCelulaProx(aux)){
        if(!strcmp(op, retornaOperadoraRoteador(RetornaCelulaItem(aux)))) OperCont++;
    }
   fprintf(SaidaArquivo, "FREQUENCIA OPERADORA %s: %d\n", op, OperCont);
   // fclose(SaidaArquivo);
   
}





//Imprime o numero de terminais cadastrados relacionados a uma determinada localização
void FrequenciaTerminal(char* local, Lista* TerminalLista,FILE* SaidaArquivo){
   
    int FreqCont=0;
    Celula* aux1;
    for(aux1 = RetornaListaPrim(TerminalLista); aux1 != NULL; aux1 = RetornaCelulaProx(aux1)){
        if(!strcmp(local, retornaOperadoraTerminal(RetornaCelulaItem(aux1)))) FreqCont++;
    }
   fprintf(SaidaArquivo, "FREQUENCIA TERMINAL %s: %d\n", local, FreqCont);
        
    

}

void liberaRoteadoresLista(Lista* RoteadorLista){
    Celula* aux1;
    for(aux1 = RetornaListaPrim(RoteadorLista); aux1 != NULL; aux1 = RetornaCelulaProx(aux1)){
        LiberaRoteador(RetornaCelulaItem(aux1));
    }
}

void liberaTerminaisLista(Lista* TerminalLista){
    Celula* aux1;
    for(aux1 = RetornaListaPrim(TerminalLista); aux1 != NULL; aux1 = RetornaCelulaProx(aux1)){
        LiberaTerminal(RetornaCelulaItem(aux1));
    }
}


//Libera a lista de terminais, depois a lista de roteadores
void encerraNetMap(Lista* RoteadorLista, Lista* TerminalLista){
    liberaTerminaisLista(TerminalLista);
    liberaRoteadoresLista(RoteadorLista);
}