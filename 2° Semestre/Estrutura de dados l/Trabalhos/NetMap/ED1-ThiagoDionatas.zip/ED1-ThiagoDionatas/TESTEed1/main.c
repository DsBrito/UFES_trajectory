#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lista.h"
#include "roteador_terminal.h"

/*
 * ################### IDEIA DA MAIN ###############################
 * FAZER APENAS A LEITURA DO ARQUIVO NA MAIN E DEIXAR O RESTO COM OS TADS.
 */
int main(int argc, char** argv) {

    Lista* TerminalLista = CriaLista();
    Lista* RoteadorLista = CriaLista();
    
    for(int i = 0; i < argc; i++)
        printf("argv[%d] :%s\n",i, argv[i]);
            
    char * CaminhoEntrada;
    CaminhoEntrada=strdup(argv[1]);
    
    FILE * f;
    FILE * ArquivoLog;
    FILE * SaidaArquivo;
    FILE* NetMapArquivo;
    f = fopen(CaminhoEntrada, "r");
    ArquivoLog = fopen("log.txt","w+");
    SaidaArquivo = fopen("saida.txt","w+");
    NetMapArquivo = fopen("saida.dot","w+");
    char * comando = (char*) malloc(sizeof (char)*50);
    
    //criar listas de roteador/terminar
    
    while (fscanf(f, "%s", comando) != EOF) {

        if (!strcmp(comando, "CADASTRAROTEADOR")) {
            char* roteador;
            fscanf(f, "%s", comando);
            roteador=strdup(comando);
            
            char* Operadora;
            fscanf(f, "%s", comando);
            Operadora=strdup(comando);
           
            //Roteador* rot = cadastraRoteador(roteador,Operadora);
            InsereRoteador(RoteadorLista, roteador,Operadora);
             
        }
        if (!strcmp(comando, "CADASTRATERMINAL")) {
            char* terminal;
            fscanf(f, "%s", comando);
            terminal=strdup(comando);
            
            char* Operadora;
            fscanf(f, "%s", comando);
            Operadora=strdup(comando);
           

            InsereTerminal(TerminalLista, terminal,Operadora);
            
        }
         
        if (!strcmp(comando, "CONECTAROTEADORES")) {           
            char* roteador1;
            fscanf(f, "%s", comando);
            roteador1=strdup(comando);
            
            char* roteador2;
            fscanf(f, "%s", comando);
            roteador2=strdup(comando);
            ConectaRoteadores(RoteadorLista,roteador1,roteador2, ArquivoLog);
            
        }

        if (!strcmp(comando, "CONECTATERMINAL")) {           
            char* terminal;
            fscanf(f, "%s", comando);
            terminal=strdup(comando);
            
            char* roteador;
            fscanf(f, "%s", comando);
            roteador=strdup(comando);
            
            ConectaTerminalRoteador(RoteadorLista, TerminalLista, terminal, roteador, ArquivoLog);
        
        }
        if (!strcmp(comando, "REMOVEROTEADOR")) {
            char* roteador;
            fscanf(f, "%s", comando);
            roteador=strdup(comando);
            RemoveRoteador(RoteadorLista,TerminalLista,roteador,ArquivoLog);
        }
        if (!strcmp(comando, "REMOVETERMINAL")) {
            char* terminal;
            fscanf(f, "%s", comando);
            terminal=strdup(comando);
            RemoveTerminal( TerminalLista, terminal,ArquivoLog);
        }

        if (!strcmp(comando, "DESCONECTAROTEADORES")) {
            char* roteador1;
            fscanf(f, "%s", comando);
            roteador1=strdup(comando);
            
            char* roteador2;
            fscanf(f, "%s", comando);
            roteador2=strdup(comando);

            DesconectaRoteadores(roteador1, roteador2, RoteadorLista, ArquivoLog);
        }
        if (!strcmp(comando, "DESCONECTATERMINAL")) {
            char* terminal;
            fscanf(f, "%s", comando);
            terminal=strdup(comando); 

            DesconectaTerminal(terminal, TerminalLista, ArquivoLog);
            

        }
        
        
        
       if (!strcmp(comando, "FREQUENCIAOPERADORA")) {
          
            char* operadora;
            fscanf(f, "%s", comando);
            operadora=strdup(comando);
            
          FrequenciaOperadora(operadora,RoteadorLista,SaidaArquivo);

       
       
       }
        
        if (!strcmp(comando, "FREQUENCIATERMINAL")) {
          
            char* local;
            fscanf(f, "%s", comando);
            local=strdup(comando);
            
          FrequenciaTerminal(local,TerminalLista,SaidaArquivo);

       
       
       }
        
         
         if (!strcmp(comando, "ENVIARPACOTESDADOS")) {
            char* terminalA;
            fscanf(f, "%s", comando);
            terminalA=strdup(comando);
            
            char* terminaB;
            fscanf(f, "%s", comando);
            terminaB=strdup(comando);
            Lista* temp = CriaLista();
            Roteador* rot1 = retornaRoteadorTerminal(RetornaTerminal(TerminalLista, terminalA));
            Roteador* rot2 = retornaRoteadorTerminal(RetornaTerminal(TerminalLista, terminaB));
            if(rot1 == NULL){
                fprintf(ArquivoLog, "%s nao possui conexao com nenhum roteador!", RetornaNomeTerminal(RetornaTerminal(TerminalLista, terminalA)));
            }
            else if(rot2 == NULL){
                fprintf(ArquivoLog, "%s nao possui conexao com nenhum roteador!", RetornaNomeTerminal(RetornaTerminal(TerminalLista, terminaB)));
            }

            else if(VerificaConexao(rot1, rot2, temp)){
                fprintf(SaidaArquivo, "ENVIARPACOTEDADOS %s %s SIM\n", RetornaNomeTerminal(RetornaTerminal(TerminalLista, terminalA)), RetornaNomeTerminal(RetornaTerminal(TerminalLista, terminaB)));
            
            }
            else{
                fprintf(SaidaArquivo, "ENVIARPACOTEDADOS %s %s NAO\n", RetornaNomeTerminal(RetornaTerminal(TerminalLista, terminalA)), RetornaNomeTerminal(RetornaTerminal(TerminalLista, terminaB)));
            }    
            liberaRoteadoresLista(temp);                     
                 
        }
         
        if (!strcmp(comando, "IMPRIMENETMAP")) {
            
        ImprimeNetMap(RoteadorLista, TerminalLista,NetMapArquivo);

        }
         if (!strcmp(comando, "FIM")) {
              fclose(SaidaArquivo);
              fclose(ArquivoLog);
              fclose(SaidaArquivo);
              fclose(NetMapArquivo);
              fclose(f);
              
            encerraNetMap(TerminalLista, RoteadorLista);
        }
        
    }
   
    
    return (EXIT_SUCCESS);
}