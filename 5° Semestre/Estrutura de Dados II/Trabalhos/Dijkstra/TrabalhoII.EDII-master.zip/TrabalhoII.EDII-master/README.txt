# TrabalhoII.EDII
Segundo Trabalho de Estrutura de Dados II

O trabalho deve ser compilado da seguinte forma:

1) tar -xzvf <nome_arquivo>.tar.gz     //descompactar o código                                                             .
2) make                                //compilar o código com o utilitário make
3) ./trab2 <nome_arquivo_entrada> <nome_arquivo_saida> //rodar o código fornecendo os nomes dos arquivos de entrada e saida
