#ifndef TRAB2ED2_PRIORITYQUEUE_H
#define TRAB2ED2_PRIORITYQUEUE_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct item Item;

typedef struct pq PQ;

PQ* pqInicializa(int maxN);

void pqInsere(PQ* fila, int key, double dist);

int pqVerificaVazia(PQ* fila);

int pqMinimo(PQ* fila);

void pqDeletaMinimo(PQ* fila);

void pqDecreaseKey(PQ* fila, int id, double valor);

void pqDestroi(PQ* fila);

#endif //TRAB2ED2_PRIORITYQUEUE_H
