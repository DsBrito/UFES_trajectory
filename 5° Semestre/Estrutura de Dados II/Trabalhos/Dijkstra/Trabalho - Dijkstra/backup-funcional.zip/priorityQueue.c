#include "./priorityQueue.h"
#include <stdlib.h>

/** Com o auxilio deste site: https://www.geeksforgeeks.org/dijkstras-shortest-path-algorithm-using-priority_queue-stl/
 * decidimos fazer essa struct Item para auxiliar nosso algoritmo utilizando priority queue*/

typedef struct item{
    double dist; //distancia
    int key; //id do item
} Item;

#define key(A) (A.key)                 // retorna identificador do nó
#define dist(A) (A.dist)               // retorna valor do nó
#define more(A, B) (dist(A) > dist(B))  // compara nós, por valor
#define exch(A, B) { Item x = A;A = B;B = x; }  // troca dois nós

struct pq {
    int n;
    int *map;
    Item *pq;
};

static void swap(Item *pq, int *map, int i, int j) {
    exch(pq[i], pq[j]);
    map[key(pq[i])] = i;
    map[key(pq[j])] = j;
}

void fix_up(Item *pq, int *map, int k) {
    while (k > 1 && more(pq[k / 2], pq[k])) {
        swap(pq, map, k, k / 2);
        k = k / 2;
    }
}

void fix_down(Item *pq, int *map, int sz, int k) {
    while (2 * k <= sz) {
        int j = 2 * k;
        if (j < sz && more(pq[j], pq[j + 1])) {
            j++;
        }
        if (!more(pq[k], pq[j])) {
            break;
        }
        swap(pq, map, k, j);
        k = j;
    }
}

PQ *pqInicializa(int maxN) {
    PQ *fila = (PQ *)malloc(sizeof(PQ));
    fila->pq = (Item *)malloc((maxN + 1) * sizeof(Item));
    fila->map = (int *)malloc((maxN + 1) * sizeof(int));
    fila->n = 0;
    return fila;
}

void pqInsere(PQ *fila, int key, double dist) {
    Item item;
    item.key = key;
    item.dist = dist;
    fila->n++;
    fila->pq[fila->n] = item;
    fila->map[key(item)] = fila->n;
    fix_up(fila->pq, fila->map, fila->n);
}

void pqDeletaMinimo(PQ *fila) {
    swap(fila->pq, fila->map, 1, fila->n);
    fila->n--;
    fix_down(fila->pq, fila->map, fila->n, 1);
}

int pqMinimo(PQ *fila) {
    return fila->pq[1].key;
}

void pqDecreaseKey(PQ *fila, int id, double valor) {
    int i = fila->map[id];
    dist(fila->pq[i]) = valor;
    fix_up(fila->pq, fila->map, i);
}

int pqVerificaVazia(PQ *fila) {
    return fila->n == 0;
}

void pqDestroi(PQ *fila) {
    free(fila->map);
    free(fila->pq);
    free(fila);
}