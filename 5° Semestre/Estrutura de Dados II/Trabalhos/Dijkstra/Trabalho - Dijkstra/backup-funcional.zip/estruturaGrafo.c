#include "estruturaGrafo.h"

/*Cada vertice possui uma vetor/lista de arestas*/
struct vertice{
    Aresta* aresta;
};

/*A areste possui o id do vertice de destino, o peso e uma seta proxima*/
struct aresta{
    Aresta* prox;
    int destino;
    long double peso;
};

/* Inicializa um vertice vazio*/
Vertice* inicVertice(){
    Vertice* vertice = (Vertice*)malloc(sizeof(Vertice));
    vertice->aresta = NULL;
    return vertice;
}

/*Constroi um vetor de vertices a partir do numero de vertices do arquivo de entrada*/
Vertice** inicVetorVertice(int numVertice){
    Vertice** vertices = (Vertice**)malloc(numVertice * sizeof(Vertice*));
    for (int i = 0; i < numVertice; i++) {
        vertices[i] = inicVertice();
    }
    return vertices;
}

/* Libera a memoria de uma lista de arestas e seu vertice*/
void destroiVertice(Vertice* vertice) {
    destroiListaAresta(vertice->aresta);
    free(vertice);
}

/* Libera a memoria de um vetor de vertices*/
void destroiVetorVertice(Vertice** vertice, int numVertice) {
    for (int i = 0; i < numVertice; i++) {
        destroiVertice(vertice[i]);
    }

    free(vertice);
}

/*Libera memoria de uma lista de arestas*/
void destroiListaAresta(Aresta* aresta) {
    Aresta* aux;
    while (aresta != NULL) {
        aux = aresta;
        aresta = aresta->prox;
        free(aux);
    }
    free(aresta);
}

/*Controi uma aresta a partir dos parametros de entrada*/
Aresta* iniciaAresta(int destino,long double peso) {
    Aresta* novaAresta = (Aresta*)malloc(sizeof(Aresta));
    novaAresta->destino = destino;
    novaAresta->peso = peso;
    novaAresta->prox = NULL;

    return novaAresta;
}

/*Insere uma aresta numa lista de vertices*/
void adicionaVertice(Vertice* vertice, int destino,long double peso){
    Aresta* novaAresta = iniciaAresta(destino, peso);

    if (vertice->aresta == NULL) {
        vertice->aresta = novaAresta;
    } else {
        novaAresta->prox = vertice->aresta;
        vertice->aresta = novaAresta;
    }
}

/*Retorna a aresta de um vertice*/
Aresta* retornaAresta(Vertice* vertice){
    return vertice->aresta;
}

/*Retorna a proxima aresta da lista*/
Aresta* retornaArestaProx(Aresta* aresta){
    return aresta->prox;
}

/*Retorna o destino de uma aresta*/
int retornaDestino(Aresta* aresta){
    return aresta->destino;
}

/*Retorna o peso de uma aresta*/
long double retornaPeso(Aresta* aresta){
    return aresta->peso;
}


