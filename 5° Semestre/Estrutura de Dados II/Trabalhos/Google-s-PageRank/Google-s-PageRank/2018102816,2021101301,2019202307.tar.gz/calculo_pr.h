#ifndef CALCULO_PR_H
#define CALCULO_PR_H

#include "rb_tree.h"

void calculatePageRank(tRBT* tree, int n_pages);

#endif