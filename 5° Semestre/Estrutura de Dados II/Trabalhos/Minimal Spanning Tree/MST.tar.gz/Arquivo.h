
#ifndef _ARQUIVO_H
#define _ARQUIVO_H


int contaLinha(FILE *f,char* argv);

#endif