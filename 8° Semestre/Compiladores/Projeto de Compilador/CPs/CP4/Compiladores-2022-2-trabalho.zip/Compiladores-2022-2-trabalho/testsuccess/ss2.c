#include <stdio.h>

int main(void) {
    int n = 2;

    if(!(n == 3)) { 
        printf("A instrução é verdadeira!\n");
    } 
    else { 
        printf("A instrução é falsa!\n");
    }

    return 0;
}
