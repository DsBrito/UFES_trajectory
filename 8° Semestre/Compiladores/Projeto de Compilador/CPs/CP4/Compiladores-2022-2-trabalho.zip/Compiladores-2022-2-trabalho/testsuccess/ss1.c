#include <stdio.h>

int main(void) {
    printf("Opa mundo!");
    return 0;
}
