#include <stdio.h>
    int main(){
    int num;
    num=10;
    printf("%d", num);
    return 0;
}