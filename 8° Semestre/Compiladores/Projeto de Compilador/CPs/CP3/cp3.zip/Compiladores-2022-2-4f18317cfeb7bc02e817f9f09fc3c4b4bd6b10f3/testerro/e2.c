#include <stdio.h>

const float pi = 3.14;

int main(void {          	//ERRO: falta parêntese
	float raio, 1area;      //ERRO: variável começando com numero
	
	printf("RAIO = ")       //ERRO: falta ponto e virgula
	scanf("%f", &raio);
 
	_area = pi * raio * raio;
 
	printf("AREA = %.2f m2 \n", 1area);

				//ERRO: não tem return
}
