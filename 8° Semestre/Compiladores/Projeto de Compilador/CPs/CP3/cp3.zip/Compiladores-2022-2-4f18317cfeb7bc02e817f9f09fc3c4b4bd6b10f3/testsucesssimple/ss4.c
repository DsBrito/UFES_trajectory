void main (char* name, int age){
    int i = 3;
    if (i == 3)
    {
      char a;
      i = -3;
    }
    a = 3;
    printf("My name is %s, I'm %d years old, Hello World!\n", name, age);
}

int main(void) {
    hello_word("Paula", 15);
    return 0;
}
