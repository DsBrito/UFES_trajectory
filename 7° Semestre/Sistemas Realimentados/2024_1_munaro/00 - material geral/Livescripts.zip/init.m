function [pn, Z] = init(I)
% Funcao para gerar parametros personalizados
pn = I;

end

