% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Resolver uma EDO
%   de 1a ordem via Euler
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X,Y1,Y2] = EulerSistemas2Eq( a, b, y1a, y2a, m ,f1, f2)
		h=(b-a)/m
		X(1) = a; 
                Y1(1) = y1a;
                Y2(1) = y2a;
                % obtendo a solucao
		for i=1:m
		  Y1(i+1) = Y1(i) + h*f1( X(i), Y1(i), Y2(i)  );
                  Y2(i+1) = Y2(i) + h*f2( X(i), Y1(i), Y2(i)  );
		  X(i+1) = X(i) + h;
		end
Y1;
Y2;
end %fim funcao


