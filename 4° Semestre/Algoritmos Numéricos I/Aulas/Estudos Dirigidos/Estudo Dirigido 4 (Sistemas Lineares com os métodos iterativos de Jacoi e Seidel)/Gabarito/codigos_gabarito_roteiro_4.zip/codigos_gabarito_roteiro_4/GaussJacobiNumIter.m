%%
%% Resolução de um sistema linear, usando método iterativo de Jacobi
%%
%% Input: Matriz A, vetor b, chute inicial,
%%			
%% Output: solução x
%%
function x = GaussJacobi_NumIter( A, b, Numiter );
  clc;
	printf('Fazendo  %d iteracoes do metodo de Gauss Jacobi para obter a solucao de Ax=b \n', Numiter);
	row = size(A,1); 
  n=row;
	% vetor chute inicial
   xold=zeros(n,1);

  for k = 1:Numiter
		for i = 1:n
			soma = 0;
			for j = 1:(i-1)
             soma = soma + A(i,j)*xold(j);
       endfor
       for j = (i+1):n
			    soma = soma + A(i,j)*xold(j);
			 endfor
			 x(i) = ( b(i) - soma) / A(i,i);
		endfor
    d = x - xold;
		
		printf('O  vetor na iteracao %d: \n', k ); x
    % atualizando o vetor de partida
		xold = x;
	endfor % Numiter
end


