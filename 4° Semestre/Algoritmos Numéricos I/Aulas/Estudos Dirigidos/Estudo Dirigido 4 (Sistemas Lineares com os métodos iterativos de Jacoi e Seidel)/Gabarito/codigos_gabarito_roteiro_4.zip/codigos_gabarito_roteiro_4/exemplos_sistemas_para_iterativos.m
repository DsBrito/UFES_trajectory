%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Arquivo com alguns exemplos de sistemas
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Exemplos com sistemas cheios

% exemplo 1
A1=[10  3 -2; 10  80 -1; 1 1 5] ;
b1=A1*ones(3,1);

% exemplo (2) 
A2=[ 13 6 9 3; 2 -41 -5 -1; -3 8 80 1; 1 2 -6 10];
b2= [31; -45 ;86 ; 7];

% A acima mas com linhas 1 e 4 trocadas
A2troc = [1 2 -6 10;  2 -41 -5 -1; -3 8 80 1; 13 6 9 3];
b2troc = [7; -45 ;86; 31];
% 

% exemplo (3)
A3=[7  2.5 1 ; 5 2 5 ; -1 1 -3];
%b3=A3*ones(3,1);
b3=[ 10.5; 12; -3];

% exemplos 2X2
A4=[1 1; 1 0.5];
b4=A4*ones(2,1);

% exemplo da apresentcao (aula) 
A5=[ 0.5 0.6 0.3; 1 1 1; 0.4 -0.4 1];
b5=[ 0.2; 0.0; -0.6];

% exemplos 2X2
A=[1 0.5; 1 1]
b=[1.5; 2.0]

%outros exemplos
% rand que converge
%{
A =[
   0.591043   0.533632   0.348564
   0.109850   0.272386   0.398848
   0.036566   0.212165   0.954932]
   
b= A*ones(3,1)
% 
%}





    


