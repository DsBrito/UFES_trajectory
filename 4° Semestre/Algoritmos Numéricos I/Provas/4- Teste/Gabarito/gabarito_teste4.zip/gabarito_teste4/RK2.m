% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Resolver uma EDO
%   de 1a ordem via RK de 2a ordem
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X,Y] = RK2( a, b, ya, m ,f);
		h=(b-a)/m;
		X(1) = a; 
    Y(1) = ya;
    % obtendo a solucao
		for i=1:m
      k1 = f( X(i),Y(i) );
      X(i+1) = X(i) + h;
      k2= f( X(i+1), Y(i) + h*k1 );
      %Y via RK2
		  Y(i+1) = Y(i) + h*( k1+ k2 )/2;
     endfor

endfunction  %fim funcao



