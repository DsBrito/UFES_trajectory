clc
% exercicios EDO q 1 e 5 teste 4
printf ('Qual exercicio vai resolver?  \n')
printf ('1 - Resolver o problema da questao 1  \n') 
printf ('5 - Resolver o problema da questao 5  \n') 
printf ('0 - Sair.\n') 
op = input ('Agora digite sua opcao: ');

if (op==1)  
  % exemplo 1 
  f = @(x,y)  (-1)*y*sin(x) 
  % sol exata
  yex = @(x)  0 ;
  a=0.0;
  b=0.6;
  ya = - 1.0;
  m = input ('qtos subintervalos (m)? ');
  %m=2;
  h=(b-a)/m
  X = zeros(1,m+1);
  Y = zeros(1,m+1);
   % 
    % sols numericas
    [X,YEuler]  = Euler ( a, b, ya, m ,f)
    % RK 2a 
    [X,YRK2]   = RK2( a, b, ya, m ,f)
    X;
    plot(X,YEuler,'g*', X, YRK2,'b*');
    titulo= 'Sol via Euler (em verde) e  Rk2a (em azul)  ';
    grid
    xlabel('x')
    ylabel('y = f(x)')
    title(titulo);
endif %op 1) 
if (op==5)
 % q 5  
   % f (x,y) = - x/y
   f = @(x,y)  -x*y^(-1)
   % y''= flin= -( x² + y²)/y^3;
   %df= @(x,y) -1.0*( x.^2 + y.^2)/(y.^3);
   % sol exata
   yex = @(x)  sqrt (17.0 - x.^2);
    % letra a e b
   %Fazendo para  um m dado m
   m = input ('qtos subintervalos (m)? ');
   X = zeros(1,m+1);
   Y = zeros(1,m+1);
   a=1.0;
   b=2.0;
   h=(b-a)/m
   ya = 4.0;
   % 
    % RK 2a 
    [X,YRK2]   = RK2( a, b, ya, m ,f)
    % RK 4a 
    [X,YRK4]   = RK4( a, b, ya, m ,f)
     % erros 
    erroRK2   = abs( YRK2 - yex(X) ) ;
    erroRK4   = abs( YRK4 - yex(X) ) ;
    % Graficos das funcoes
    titulo= 'Sol via  Rk2a (azul) e  Rk4a (magenta) ';
    %plot( X, YRK2,'b*', X, YRK4,'mo');
    %grid
    %xlabel('x')
    %ylabel('y = f(x)')  
    %title(titulo);
    % letra c
    discretizacao=[5 10 20 40];
    for  i =1:length(discretizacao)
         m= discretizacao(i);
         % RK 2a 
         [X,YRK2]   = RK2( a, b, ya, m ,f);
         % RK 4a 
         [X,YRK4]   = RK4( a, b, ya, m ,f);
         % erros em x=b
         erroRK2_em_b(i)   = abs( YRK2(m+1) - yex(b) ); 
         erroRK4_em_b(i)   = abs( YRK4(m+1) - yex(b) );
    endfor
    disp('erro em x=b, para RK2a ordem')
    erroRK2_em_b
    disp('erro em x=b, para RK2a ordem')
    erroRK4_em_b
    % Graficos dos erros  (erro em todos os pontos do dominio)
    titulo= 'Erro  via Rk2a (azul) e  via Rk4a (magenta) em x=b, para diversas discretizacoes (m) ';
    plot( discretizacao, erroRK2_em_b,'b*', discretizacao, erroRK4_em_b,'mo');
    grid
    xlabel('m')
    ylabel('erros  ')
    title(titulo);

endif

if (op==4)
  % Sistema  Presa Predador
  
endif





