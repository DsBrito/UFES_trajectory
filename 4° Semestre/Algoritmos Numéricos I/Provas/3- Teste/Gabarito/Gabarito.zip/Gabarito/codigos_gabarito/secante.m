%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Calcula novas aproximacoes para a raiz  de 
%    uma funcao f(x) pelo metodo da SECANTE
% 
%   Dados de Entrada:  chutes inicial (x1 e x2) 
%		                   precisao  (tol)
%                      A qte maxima de iteracoes (NumiterMAX)
%                      f(x) e f'(x)  (f e sua derivada)
%
%   Saida:  o vetor com a sequencia de de aproximacoes, 
%           qte de iteracoes, e o valor da ultima distacia (relativa)  entre os pontos
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
function  [raiz, x, qteIter, distrel] = secante( x1 , x2 ,tol, NumMAXiter,  f);
%
qteIter=0;
distrel=1.0;
x(1)= x1;
x(2)= x2;
disp("Rodando o  metodo da secante -----------"); 
% processo iterativo;
k=2;
while (distrel > tol) && ( qteIter < NumMAXiter) 
   % avaliando a funcao e a sua derivada  
    fkmenos1 = f( x(k-1) );
    fk = f(x(k));
    d = x(k-1)- x(k);    
   % gerando o novo ponto
   x(k+1) = x(k) -  ( fk*d/(fkmenos1-fk) );
   raiz=  x(k+1);
   % calculando a dist relativa
   dist= x(k+1) -x(k);
   distrel= abs( dist/x(k+1) );
   % atualizando os contadores 
   k= k+1;
   qteIter= qteIter+1;
end
x;
qteIter;
endfunction
