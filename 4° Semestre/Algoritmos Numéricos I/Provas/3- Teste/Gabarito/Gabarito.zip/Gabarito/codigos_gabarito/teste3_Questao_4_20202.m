clc
% teste 3
printf("Digite uma opcao:\n");
printf("1 - Resolver o problema 1 (validacao).\n");
printf("2 - Resolver o problema 2 (do tanque esferico).\n");
printf("3 - Resolver o problema 3 (um exemplo qualquer escolhido pelo aluno).\n");
printf("4 - Sair\n\n");
op = input ('Sua opcao: ');

%Fazendo com um valor fixo para NumMAXiter 
NumMAXiter= 50;
% alternativa seria
%NumMAXiter = input("digite  a digite qte maxima de iteracoes: ");

if (op==1)   % validacao 
     % via secante 
     disp('Resolvendo pela secante  para a funcao f(x)= x^2-7');
     f = @(x) x.^2-7;
     xinicial1 = input ('digite o valor inicial: ');
     xinicial2 = input ('digite o valor inicial: ');
     tol = input("digite  a digite tol: ");
     [raiz, x, qteIter, distrel] = secante( xinicial1 , xinicial2, tol, NumMAXiter,  f)
endif
if (op==2)  % tanque esferico
     disp('Resolvendo o problema  para  2');
     r=3.0;
    % obtendo altura para que V(x)=25  -> f(x)=V(x)-25 =0
     f =  @(x) (1/3)*pi*(x.^2).*(3*r-x) -25;  
     % via secante 
     xinicial1 = input ('digite o valor inicial: ');
     xinicial2 = input ('digite o valor inicial: ');
     tol = input("digite  a digite tol: ");
     [raiz, x, qteIter, distrel] = secante( xinicial1 , xinicial2, tol, NumMAXiter,  f)
endif    
if (op==3)
     disp(' Resolvendo o problema  com f(x)= x^3- exp(x) ')
     f  = @(x)   x.^3- exp(x);
    % via secante 
     xinicial1 = input ('digite o valor inicial: ');
     xinicial2 = input ('digite o valor inicial: ');
     tol = input("digite  a digite tol: ");
     [raiz, x, qteIter, distrel] = secante( xinicial1 , xinicial2, tol, NumMAXiter,  f)
endif
if (op==4)
   disp(' fim');
endif

