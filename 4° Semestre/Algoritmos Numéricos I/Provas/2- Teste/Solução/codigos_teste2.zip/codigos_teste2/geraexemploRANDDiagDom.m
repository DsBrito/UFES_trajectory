%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    Gera um sistema linear  Ax=b de dimensao n 
%    cujos elementos  que não estao na diagonal principal, são quaisquer, gerados  aleatoreamente  entre 0 e 1
%    O elemento da diagonal principal eh a soma dos demais (em modulo), em cada linha
%   
%   O sistema gerando eh tal que a solução eh x=[1.0,1.0,...,1.0,1.0] 
%   
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Input:   dimensao do sistema
%% Output:  matriz A e vetor b 
%
%%   usage  
%   >> [A,b]= geraexemploRANDDiagDom(n);
%
function [A,b] = geraexemploRANDDiagDom(n);
  
   A= zeros(n,n); %coloca zeros em todas as posiçoes
  
    for i=1:n
      s=0;
       for j=1:n
         A(i,j)=rand;
         s = s + abs( A(i,j));
       endfor
       A(i,i)=s;
    endfor
    % Gerando um vetor b tal que a solução seja x=[1.0,1.0,...,1.0,1.0] 
    % isto é calculando  b=A*[1.0,1.0,...,1.0,1.0]
    b = A*ones(n,1);

endfunction %fim funcao
  




