%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%    Gera um sistema linear pentadiaognal (especifico)
%     de dimensao n (com vetor b particular) 
%   
%  Input:   dimensao do sistema n
%  Output:  matriz A e vetor b 
%
%  usage   function [A,b] = geraexemploPenta(n)
%

function [A,b] = geraexemploPenta(n)

    % exemplo com valores especificos  para as "diagonais"
    da=15.0;  db=-6.0;  Dp=4;   dc=12.0;  dd=-15.5;
    %
    % 1a linha
    A(1,1)=Dp; A(1,2)= dc; A(1,3)= dd;
    % 2a linha
    A(2,1)=db; A(2,2)=Dp; A(2,3)= dc;  A(2,4)= dd;
    
   % linha i qq 
   for i = 3:(n-2);
      A(i,i-2)=da;  A(i,i-1)=db;  A(i,i)=Dp;  A(i,i+1)=dc;  A(i,i+2)=dd; 
   end;     
    % penultima linha
    i=(n-1);
    A(i,i-2)=da;  A(i,i-1)=db;  A(i,i)=Dp;  A(i,i+1)=dc;
    % ultima
    i=n;
    A(i,i-2)=da;  A(i,i-1)=db;  A(i,i)=Dp;
    
    % Gerando um vetor b tal que a solução seja x=[1.0,1.0,...,1.0,1.0] 
    % isto é calculando  b=A*[1.0,1.0,...,1.0,1.0]
    b = A*ones(n,1);

   
endfunction %fim funcao


