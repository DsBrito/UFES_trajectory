%%
%% Resolução de um sistema linear, usando método iterativo de Jacobi
%%
%% Input: Matriz A, vetor b, tol, maxiter
%%			
%% Output: solução x
%%
function x = GaussJacobi( A, b, tol, maxiter);
  clc;
	fprintf(' Fazendo  o metodo de Gauss Jacobi para obter a solucao de Ax=b \n');
	row = size(A,1); 
  n=row;
	dr = 1 ;		% distância inicial
	k = 0;
	% vetor chute inicial
  xold=zeros(n,1);

 while  (dr  >  tol) &&  (k < maxiter)
		for i = 1:n
			soma = 0;
			for j = 1:(i-1)
              soma = soma + A(i,j)*xold(j);
      endfor
      for j = (i+1):n
			    soma = soma + A(i,j)*xold(j);
			endfor
			x(i) = ( b(i) - soma) / A(i,i);
		end

    dr= distrel(x,xold);
    k=k+1;
		%fprintf(' Vetor na iteracao %d,   ', k);
                %x
                % atualizando o vetor de partida
		xold = x;
endwhile % fim  repeticoes
printf(' qte de iteracoes %d,   ', k);
dr
end


